Ejemplos PHP de Banorte Payworks
====================

Ejemplos de código para procesar pagos con Banorte Payworks en PHP.

Tarjeta de pruebas
----------
Se pueden utilizar los siguientes datos para hacer pruebas cuando utilizando los modos Y, N o R  
**VISA**  
**4111 1111 1111 1111**  
**EXP. 12/16 CCV. 111**

Arturo León  
arturo@pincel.mx  
http://www.arturoleon.net
